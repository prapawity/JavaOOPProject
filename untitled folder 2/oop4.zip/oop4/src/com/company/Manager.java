package com.company;

public class Manager extends Employee {
    String department;

    @Override
    public void showDetail(){

    }

    public static void main(String[] args) {
        Manager manager = new Manager();
    }
}
